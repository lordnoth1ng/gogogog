using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace LibraryManagementSystem.Tests
{
    [TestFixture]
    public class BookManagerTests
    {
        private BookManager _bookManager;

        [SetUp]
        public void Setup()
        {
            _bookManager = new BookManager();
        }

        [Test]
        public void AddBook_ShouldAddBook_WhenBookDoesNotExist()
        {
            var book = new Book("1", "Title", "Author", 2023);
            _bookManager.AddBook(book);
            Assert.AreEqual(1, _bookManager.GetAllBooks().Count);
        }

        [Test]
        public void AddBook_ShouldThrowException_WhenBookAlreadyExists()
        {
            var book = new Book("1", "Title", "Author", 2023);
            _bookManager.AddBook(book);

            var ex = Assert.Throws<Exception>(() => _bookManager.AddBook(book));
            Assert.That(ex.Message, Is.EqualTo("����� � ����� ��������������� ��� ����������."));
        }

        [Test]
        public void RemoveBook_ShouldRemoveBook_WhenBookExists()
        {
            var book = new Book("1", "Title", "Author", 2023);
            _bookManager.AddBook(book);
            _bookManager.RemoveBook("1");
            Assert.AreEqual(0, _bookManager.GetAllBooks().Count);
        }

        [Test]
        public void RemoveBook_ShouldThrowException_WhenBookDoesNotExist()
        {
            var ex = Assert.Throws<Exception>(() => _bookManager.RemoveBook("2"));
            Assert.That(ex.Message, Is.EqualTo("����� �� �������."));
        }

        [Test]
        public void GetBook_ShouldReturnBook_WhenBookExists()
        {
            var book = new Book("1", "Title", "Author", 2023);
            _bookManager.AddBook(book);
            var retrievedBook = _bookManager.GetBook("1");
            Assert.AreEqual(book, retrievedBook);
        }

        [Test]
        public void GetBook_ShouldThrowException_WhenBookDoesNotExist()
        {
            var ex = Assert.Throws<Exception>(() => _bookManager.GetBook("2"));
            Assert.That(ex.Message, Is.EqualTo("����� �� �������."));
        }
    }
}

