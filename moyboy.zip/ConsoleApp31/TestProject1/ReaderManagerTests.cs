﻿using NUnit.Framework;
using System;

namespace TestProject1
{
    [TestFixture]
    public class ReaderManagerTests
    {
        private ReaderManager _readerManager;

        [SetUp]
        public void Setup()
        {
            _readerManager = new ReaderManager();
        }

        [Test]
        public void AddReader_ShouldAddReader_WhenReaderDoesNotExist()
        {
            var reader = new Reader("1", "Reader Name", "reader@example.com");
            _readerManager.AddReader(reader);
            Assert.AreEqual(1, _readerManager.GetAllReaders().Count);
        }

        [Test]
        public void AddReader_ShouldThrowException_WhenReaderWithSameIdExists()
        {
            var reader = new Reader("1", "Reader Name", "reader@example.com");
            _readerManager.AddReader(reader);

            var duplicateReader = new Reader("1", "Another Reader", "another@example.com");
            var ex = Assert.Throws<Exception>(() => _readerManager.AddReader(duplicateReader));
            Assert.AreEqual("Читатель с таким идентификатором уже существует.", ex.Message);
        }

        [Test]
        public void RemoveReader_ShouldRemoveReader_WhenReaderExists()
        {

            var reader = new Reader("1", "Reader Name", "reader@example.com");
            _readerManager.AddReader(reader);
            _readerManager.RemoveReader("1");
            Assert.AreEqual(0, _readerManager.GetAllReaders().Count);
        }

        [Test]
        public void RemoveReader_ShouldThrowException_WhenReaderDoesNotExist()
        {
            var ex = Assert.Throws<Exception>(() => _readerManager.RemoveReader("1"));
            Assert.AreEqual("Читатель не найден.", ex.Message);
        }

        [Test]
        public void GetReader_ShouldReturnReader_WhenReaderExists()
        {
            var reader = new Reader("1", "Reader Name", "reader@example.com");
            _readerManager.AddReader(reader);
            var retrievedReader = _readerManager.GetReader("1");
            Assert.AreEqual(reader, retrievedReader);
        }

        [Test]
        public void GetReader_ShouldThrowException_WhenReaderDoesNotExist()
        {
            var ex = Assert.Throws<Exception>(() => _readerManager.GetReader("1"));
            Assert.AreEqual("Читатель не найден.", ex.Message);
        }
    }
}
