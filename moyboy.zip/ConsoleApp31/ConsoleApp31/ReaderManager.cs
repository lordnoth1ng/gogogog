﻿using ConsoleApp31;
using System;
using System.Collections.Generic;

public class ReaderManager
{
    public List<Reader> Readers { get; private set; }

    public ReaderManager()
    {
        Readers = new List<Reader>();
    }

    public void AddReader(Reader reader)
    {
        if (Readers.Exists(r => r.Id == reader.Id))
        {
            throw new Exception("Читатель с таким идентификатором уже существует.");
        }
        Readers.Add(reader);
    }

    public void RemoveReader(string readerId)
    {
        var reader = Readers.Find(r => r.Id == readerId);
        if (reader == null)
        {
            throw new Exception("Читатель не найден.");
        }
        Readers.Remove(reader);
    }

    public Reader GetReader(string readerId)
    {
        var reader = Readers.Find(r => r.Id == readerId);
        if (reader == null)
        {
            throw new Exception("Читатель не найден.");
        }
        return reader;
    }

    public List<Reader> GetAllReaders()
    {
        return Readers;
    }
}
