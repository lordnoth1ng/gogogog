﻿using System;
using System.Collections.Generic;

public class BookManager
{
    public List<Book> Books { get; private set; }

    public BookManager()
    {
        Books = new List<Book>();
    }

    public void AddBook(Book book)
    {
        if (Books.Exists(b => b.Id == book.Id))
        {
            throw new Exception("Книга с таким идентификатором уже существует.");
        }
        Books.Add(book);
    }

    public void RemoveBook(string bookId)
    {
        var book = Books.Find(b => b.Id == bookId);
        if (book == null)
        {
            throw new Exception("Книга не найдена.");
        }
        Books.Remove(book);
    }

    public Book GetBook(string bookId)
    {
        var book = Books.Find(b => b.Id == bookId);
        if (book == null)
        {
            throw new Exception("Книга не найдена.");
        }
        return book;
    }

    public List<Book> GetAllBooks()
    {
        return Books;
    }
}